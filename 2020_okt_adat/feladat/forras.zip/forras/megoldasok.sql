﻿-- A feladatok megoldására elkészített SQL parancsokat illessze be a feladat sorszáma után!

-- 10. feladat:


-- 12. feladat:


-- 13. feladat:


-- 14. feladat:


-- 15. feladat:

 
-- 16. feladat:

  
-- 17. feladat:

